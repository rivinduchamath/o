package com.sliit.mtit.osgi.roomproducer;

import java.util.HashMap;
import java.util.Scanner;

public class RoomServicePublishImpl implements RoomServicePublish { // Class Implement RoomServicePublish Interface
	@Override
	public RoomDetail displayRooms() {// Override Method From RoomServicePublish Interface
	
	int amount = 0;
	String room = "";
	HashMap<Integer, String> type = new HashMap<Integer, String>(); // HashMap to Store Room Type
	
	type.put(1, "Deluxe Queen Room Rs: 25000.00 "); // Data adding to HashMap "type"
	type.put(2, "Deluxe King Room Rs: 30000.00 ");
	type.put(3, "Executive King Room Rs: 35000.00 ");
	type.put(4, "Premier King Room Rs: 45000.00 ");
	type.put(5, "The Radh Premier Suite Rs: 50000.00 ");
	type.put(6, "Garden Suite with Plunge Pool Rs: 65000.00 ");
	
	System.out.println("Room Service Publisher start");
	System.out.println();
	System.out.println("*****************Welcome to Hotel Jetwing Lighthouse*****************"); // Print Room Menu From Hash Map
	System.out.println("------------Room List-------------------------------");
	System.out.println(type.get(1)+" = 1");       
	System.out.println(type.get(2)+" = 2");
	System.out.println(type.get(3)+" = 3");
	System.out.println(type.get(4)+" = 4");
	System.out.println(type.get(5)+" = 5");
	System.out.println(type.get(6)+" = 6");
	System.out.println("\n*****************End Of Room List*****************");
	System.out.println();
	
	String conBuy = "N";
	while (conBuy.equalsIgnoreCase("N")) { // Run while Room In the Cart

		System.out.print("Enter Room Number :");
		Scanner optionKey = new Scanner(System.in);
		int selector = optionKey.nextInt();

		 HashMap<Integer, Integer> price = new HashMap<Integer, Integer>();// HashMap to Store Room Price
		price.put(1, 25000);
		price.put(2, 30000);
		price.put(3, 35000);
		price.put(4, 45000);
		price.put(5, 50000);
		price.put(6, 65000);

	switch (selector) { // Switch Case For print selected Room Type and Price

		case 1:
			amount = amount + (Integer)price.get(1);
			room = type.get(1)+"";
			System.out.println("Room Price RS : "+ price.get(1));
			break;

		case 2:
			amount = amount + (Integer)price.get(2);
			room = type.get(2)+"";
			System.out.println("Room Price RS : "+ price.get(2));
			break;

		case 3:
			amount = amount + (Integer)price.get(3);
			room = type.get(3)+"";
			System.out.println("Room Price RS : "+ price.get(3));
			break;

		case 4:
			amount = amount + (Integer)price.get(4);
			room = type.get(4)+"";
			System.out.println("Room Price RS : "+ price.get(4));
			break;
	
		case 5:
			amount = amount + (Integer)price.get(5);
			room = type.get(5)+"";
			System.out.println("Room Price RS : "+ price.get(5));
			break;

		case 6:
			amount = amount + (Integer)price.get(6);
			room = type.get(6)+"";
			System.out.println("Room Price RS : "+ price.get(6));
			break;

		default:
			System.out.println("Invalid Room Number. Please enter valid number");
			continue;
	}//End Switch 
	 
	System.out.print("Do you Want to ADD To Cart? (Y/N): "); //Confirmation
	Scanner contuBUY = new Scanner(System.in);
	
	if(contuBUY.next().equals("Y") || contuBUY.next().equals("y")) { // Change conBuy to stop While loop After Select Room
	conBuy = contuBUY.next();
	}
	}//End While
	
	return new RoomDetail(conBuy,room, amount); // Return New RoomDetail Object
	}//End Method

}//End Class
