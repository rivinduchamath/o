package com.sliit.mtit.osgi.roomproducer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

	ServiceRegistration publishServiceRegistrion;

	public void start(BundleContext context) throws Exception {
		RoomServicePublish publisherService = new RoomServicePublishImpl();
		publishServiceRegistrion = context.registerService(RoomServicePublish.class.getName(), publisherService, null);
		System.out.println("Start Room Service");
	}

	public void stop(BundleContext bundleContext) throws Exception {
		System.out.println("Stop Publisher");
		publishServiceRegistrion.unregister();
		System.out.println("Stop Room Service");
	}
	
}
