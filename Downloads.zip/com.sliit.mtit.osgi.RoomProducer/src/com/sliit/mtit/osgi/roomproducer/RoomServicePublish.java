package com.sliit.mtit.osgi.roomproducer;

public interface RoomServicePublish {

	RoomDetail displayRooms();

}
