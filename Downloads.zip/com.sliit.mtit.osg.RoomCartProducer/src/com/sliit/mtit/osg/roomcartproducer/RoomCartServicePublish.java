package com.sliit.mtit.osg.roomcartproducer;

public interface RoomCartServicePublish {
	String cartMenu(double tot);
}
