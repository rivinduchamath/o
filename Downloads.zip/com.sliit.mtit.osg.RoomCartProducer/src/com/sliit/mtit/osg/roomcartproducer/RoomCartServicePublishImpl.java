package com.sliit.mtit.osg.roomcartproducer;

import java.util.Scanner;

public class RoomCartServicePublishImpl implements RoomCartServicePublish{

	@Override
	public String cartMenu(double tot) {
		System.out.println("Room/s total cost is : Rs." +tot);
		System.out.print("Do you want to Book? (Y/N): ");// Confirmation
		Scanner response = new Scanner(System.in);
		String buy = response.next();
		return buy;
	}
}