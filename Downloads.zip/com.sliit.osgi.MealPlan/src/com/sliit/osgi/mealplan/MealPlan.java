package com.sliit.osgi.mealplan;


public interface MealPlan {
	MealDetails displayMeals();
}
