package com.sliit.osgi.mealplan;

import java.util.Hashtable;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;
import org.osgi.util.tracker.ServiceTracker;



public class Activator implements BundleActivator {

	
	ServiceRegistration publishServiceRegistrion;
	
	public void start(BundleContext context) throws Exception {
		MealPlan publisherService = new MealPlanImpl();
		publishServiceRegistrion = context.registerService(MealPlan.class.getName(), publisherService, null);
		System.out.println("Start Room Service");
	}

	public void stop(BundleContext bundleContext) throws Exception {
		System.out.println("Stop Publisher");
		publishServiceRegistrion.unregister();
		System.out.println("Stop Room Service");
	}
	
}
