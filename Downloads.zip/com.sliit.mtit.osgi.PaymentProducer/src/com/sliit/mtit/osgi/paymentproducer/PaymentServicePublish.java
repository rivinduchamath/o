package com.sliit.mtit.osgi.paymentproducer;

public interface PaymentServicePublish {
	PaymentObject displayPayment();

}
